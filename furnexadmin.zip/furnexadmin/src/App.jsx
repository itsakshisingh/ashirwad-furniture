import { Navigate, Route, Routes } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import { BannersPage, CategoriesPage } from "./pages/SimpleResources";
import Products from "./pages/Products";
import ProductForm from "./pages/ProductForm";
import Inquiries from "./pages/Inquiries";
import Gallery from "./pages/Gallery";
import Reviews from "./pages/Reviews";
import ProductReviews from "./pages/ProductReviews";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="banners" element={<BannersPage />} />
          <Route path="categories" element={<CategoriesPage />} />
          <Route path="products" element={<Products />} />
          <Route path="products/new" element={<ProductForm />} />
          <Route path="products/:id/edit" element={<ProductForm />} />
          <Route path="gallery" element={<Gallery />} />
          <Route path="product-reviews" element={<ProductReviews />} />
          <Route path="reviews" element={<Reviews />} />
          <Route path="stats" element={<Reviews />} />
          <Route path="inquiries" element={<Inquiries />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
